# Coffee-Shop-Sales
An Excel Project Showcasing all the sales done over the year by analyzing the whole database
